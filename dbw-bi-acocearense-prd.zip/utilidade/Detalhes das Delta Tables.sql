-- Databricks notebook source
-- DBTITLE 1,detalhes da partição onde a tb foi persistida
describe detail silver.conta

-- COMMAND ----------

-- DBTITLE 1,tipos de dados e colunas da tb
describe silver.conta

-- COMMAND ----------

-- DBTITLE 1,ver o histórico da delta table
DESCRIBE HISTORY silver.conta

-- COMMAND ----------

-- DBTITLE 1,Selecionar uma tabela em uma versão especifica
SELECT * from  silver.conta VERSION AS OF 14

-- COMMAND ----------

-- DBTITLE 1,Revertendo uma tabela para uma versão em especifico
RESTORE TABLE silver.conta TO VERSION AS OF 15
