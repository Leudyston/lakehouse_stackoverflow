# Databricks notebook source
from pyspark.sql import functions as f
from pyspark.sql.utils import AnalysisException

# COMMAND ----------

dbutils.widgets.text("pn_chave_entidade", "")
vn_chave_entidade = dbutils.widgets.get("pn_chave_entidade")
print('vn_chave_entidade: ' + vn_chave_entidade)

# COMMAND ----------

try:
    data = (
         spark.table("log.pipeline_execucao")
            .where((f.col("chave_entidade") == vn_chave_entidade) & (f.col("flg_pipeline_status") == 1))
            .agg(f.max("dt_ini_execucao").alias("dt_max_ini_execucao"))
            .select(f.date_format(f.col("dt_max_ini_execucao") - f.expr("INTERVAL 2 HOURS"),'yyyy-MM-dd hh:mm:ss'))
            .collect()[0][0]
    )
    if data == None:
        dbutils.notebook.exit('1900-01-01 00:00:00')
    else:
        dbutils.notebook.exit(data)
        
except AnalysisException as ex: 
    dbutils.notebook.exit('1900-01-01 00:00:00')
