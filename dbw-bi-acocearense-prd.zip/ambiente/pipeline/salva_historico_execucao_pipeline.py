# Databricks notebook source
# DBTITLE 1,Recebe parâmetro de ingestão passada no Data Factory.
dbutils.widgets.text("pn_chave_entidade", "")
vn_chave_entidade = dbutils.widgets.get("pn_chave_entidade")
print('vn_chave_entidade: ' + vn_chave_entidade)

dbutils.widgets.text("pn_id_pipeline_run", "")
vn_id_pipeline_run = dbutils.widgets.get("pn_id_pipeline_run")
print('vn_id_pipeline_run: ' + vn_id_pipeline_run)

dbutils.widgets.text("pn_dt_param_ini_carga", "")
vn_dt_param_ini_carga = dbutils.widgets.get("pn_dt_param_ini_carga")
print('vn_dt_param_ini_carga: ' + vn_dt_param_ini_carga)

dbutils.widgets.text("pn_tipo_carga", "")
vn_tipo_carga = dbutils.widgets.get("pn_tipo_carga")
print('vn_tipo_carga: ' + vn_tipo_carga)

dbutils.widgets.text("pn_dt_ini_execucao", "")
vn_dt_ini_execucao = dbutils.widgets.get("pn_dt_ini_execucao")
print('vn_dt_ini_execucao: ' + vn_dt_ini_execucao)

dbutils.widgets.text("pn_dt_fim_execucao", "")
vn_dt_fim_execucao = dbutils.widgets.get("pn_dt_fim_execucao")
print('vn_dt_fim_execucao: ' + vn_dt_fim_execucao)

dbutils.widgets.text("pn_flg_pipeline_status", "")
vn_flg_pipeline_status = dbutils.widgets.get("pn_flg_pipeline_status")
print('vn_flg_pipeline_status: ' + vn_flg_pipeline_status)

dbutils.widgets.text("pn_desc_pipeline_status", "")
vn_desc_pipeline_status = dbutils.widgets.get("pn_desc_pipeline_status")
print('vn_desc_pipeline_status: ' + vn_desc_pipeline_status)

dbutils.widgets.text("pn_pipeline_erro_mensagem", "")
vn_pipeline_erro_mensagem = dbutils.widgets.get("pn_pipeline_erro_mensagem")
print('vn_pipeline_erro_mensagem: ' + vn_pipeline_erro_mensagem)

dbutils.widgets.text("pn_pipeline_erro_target", "")
vn_pipeline_erro_target = dbutils.widgets.get("pn_pipeline_erro_target")
print('vn_pipeline_erro_target: ' + vn_pipeline_erro_target)

# COMMAND ----------

# DBTITLE 1,Tratamento do Erro
def multipleReplace(text):
    for char in ".'-!?/_[]();":
        text = str(text).replace(char, "")
    
    return text

# COMMAND ----------

vn_pipeline_erro_mensagem_tratada = multipleReplace(vn_pipeline_erro_mensagem)
print(vn_pipeline_erro_mensagem_tratada)

# COMMAND ----------

# DBTITLE 1,Inclusão do Log
## Registros fakes para testar o insert
# vn_chave_entidade = "teste"
# vn_id_pipeline_run = "-"
# vn_dt_param_ini_carga = "1900-01-01 00:00:00"
# vn_tipo_carga = "-"
# vn_dt_ini_execucao = "1900-01-01 00:00:00"
# vn_dt_fim_execucao = "1900-01-01 00:00:00"
# vn_flg_pipeline_status = 1
# vn_desc_pipeline_status = "-"
# vn_pipeline_erro_mensagem = "-"
# vn_pipeline_erro_target = "-"

spark.sql(f"""
    INSERT INTO log.pipeline_execucao (chave_entidade, id_pipeline_run, dt_param_ini_carga, tipo_carga, dt_ini_execucao, dt_fim_execucao, flg_pipeline_status, desc_pipeline_status, pipeline_erro_mensagem, pipeline_erro_target) 
    VALUES ('{vn_chave_entidade}', '{vn_id_pipeline_run}', '{vn_dt_param_ini_carga}', '{vn_tipo_carga}', '{vn_dt_ini_execucao}', '{vn_dt_fim_execucao}', '{vn_flg_pipeline_status}', '{vn_desc_pipeline_status}', '{vn_pipeline_erro_mensagem_tratada}', '{vn_pipeline_erro_target}')
""")
