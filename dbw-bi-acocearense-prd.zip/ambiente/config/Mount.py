# Databricks notebook source
# MAGIC %md
# MAGIC ## Vinculando o ADLS e o Key Vault ao Databricks
# MAGIC   * Pode seguir esse tutorial sem problemas: https://towardsdatascience.com/mounting-accessing-adls-gen2-in-azure-databricks-using-service-principal-and-secret-scopes-96e5c3d6008b
# MAGIC   * Para criar o escopo: https://adb-2909305270621762.2.azuredatabricks.net/?o=2909305270621762#secrets/createScope

# COMMAND ----------

# MAGIC %md
# MAGIC ## Montar

# COMMAND ----------

configs = {"fs.azure.account.auth.type": "OAuth",
          "fs.azure.account.oauth.provider.type": "org.apache.hadoop.fs.azurebfs.oauth2.ClientCredsTokenProvider",
          "fs.azure.account.oauth2.client.id": dbutils.secrets.get(scope="scopekeydbwdev",key="keyclientid"),
          "fs.azure.account.oauth2.client.secret": dbutils.secrets.get(scope="scopekeydbwdev",key="keyadlsdbw"),
          "fs.azure.account.oauth2.client.endpoint": "https://login.microsoftonline.com/" + dbutils.secrets.get(scope="scopekeydbwdev",key="keytenantid") + "/oauth2/token"}

# configs = {"fs.azure.account.auth.type": "OAuth",
#           "fs.azure.account.oauth.provider.type": "org.apache.hadoop.fs.azurebfs.oauth2.ClientCredsTokenProvider",
#           "fs.azure.account.oauth2.client.id": "4e82e80e-5533-4c3a-b189-86adb4d6a544",
#           "fs.azure.account.oauth2.client.secret": "LwY8Q~6sks-~A3W9ycRCnygIHKFq1DHgfvWX~c_k",
#           "fs.azure.account.oauth2.client.endpoint": "https://login.microsoftonline.com/9c9c8341-d469-42a5-a3b1-68e24680f993/oauth2/token"}

# COMMAND ----------



# COMMAND ----------

# DBTITLE 1,Função para Criar um Mount Point
def create_mount_point(container, folder=None): 
    if folder is None: 
        _source = f"abfss://{container}@stbiacocearenseprd.dfs.core.windows.net"
        _mount_point = f"/mnt/{container}/"
    else:
        _source = f"abfss://{container}@stbiacocearenseprd.dfs.core.windows.net/{folder}"
        _mount_point = f"/mnt/{folder}/"
    
    if any(mount.mountPoint == _mount_point for mount in dbutils.fs.mounts()):
        return f"Já existe esse mount point criado: {_mount_point}."
    else:
        dbutils.fs.mount(
            source = _source,
            mount_point = _mount_point,
            extra_configs = configs
        )
        return f"Show! Mount point criado! {_mount_point} >> {dbutils.fs.ls(_mount_point)}"

# COMMAND ----------

# create_mount_point("log")
# create_mount_point("raw")
# create_mount_point("delta")
# create_mount_point("delta", "bronze")
# create_mount_point("delta", "silver")
# create_mount_point("delta", "gold")
# create_mount_point("gerencia")

# COMMAND ----------

# MAGIC %md
# MAGIC #### Desmontar

# COMMAND ----------

# DBTITLE 1,Função de Deletar um Ponto de Montagem
def sub_unmount(str_path):
    if any(mount.mountPoint == str_path for mount in dbutils.fs.mounts()):
        dbutils.fs.unmount(str_path)
    else:
        return f"Não existe essa montagem: {str_path}"

# COMMAND ----------

# sub_unmount("/mnt/log/")
# sub_unmount("/mnt/raw/")
# sub_unmount("/mnt/delta/")
# sub_unmount("/mnt/bronze/")
# sub_unmount("/mnt/silver/")
# sub_unmount("/mnt/gold/")
# sub_unmount("/mnt/trusted/")
# sub_unmount("/mnt/refined/")

# COMMAND ----------

# MAGIC %md
# MAGIC #### Listar

# COMMAND ----------

def list_mount_point(str_path):
    if any(mount.mountPoint == str_path for mount in dbutils.fs.mounts()):
        return dbutils.fs.ls(str_path)
    else:
        return f"Não existe essa montagem: {str_path}"

# COMMAND ----------

list_mount_point("/mnt/log/")
list_mount_point("/mnt/raw/")
list_mount_point("/mnt/bronze/")
list_mount_point("/mnt/silver/")
list_mount_point("/mnt/gold/")
list_mount_point("/mnt/delta/")
# list_mount_point("/mnt/trusted/")
# list_mount_point("/mnt/refined/")

# COMMAND ----------

# MAGIC %fs ls "dbfs:/mnt/log/pipeline/pipeline_execucao"

# COMMAND ----------

# para quando parar de funcionar o protocolo abfs utilizar o wasbs: 
# dbutils.fs.mount(
#    source = "wasbs://[container]@adlsprdbmais.blob.core.windows.net/[folder]",
#    mount_point = "/mnt/[folder]/"
#    extra_configs = {"fs.azure.account.key.adlsprdbmais.blob.core.windows.net" : dbutils.secrets.get(scope = "escopo-kv-dados-prd-bmais", key = "escopo-kv-dados-prd-bmais")}
# )
