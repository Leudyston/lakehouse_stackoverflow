-- Databricks notebook source
CREATE DATABASE IF NOT EXISTS bronze;
CREATE DATABASE IF NOT EXISTS silver;
CREATE DATABASE IF NOT EXISTS gold;
CREATE DATABASE IF NOT EXISTS log;

-- COMMAND ----------

DROP TABLE IF EXISTS log.pipeline_execucao;
CREATE TABLE log.pipeline_execucao (
    id bigint GENERATED ALWAYS AS IDENTITY,
    chave_entidade string NOT NULL,
    id_pipeline_run string NOT NULL,
    dt_param_ini_carga timestamp NOT NULL,
    tipo_carga string NOT NULL,
    dt_ini_execucao timestamp NOT NULL,
    dt_fim_execucao timestamp,
    flg_pipeline_status int, 
    desc_pipeline_status string,
    pipeline_erro_mensagem string,
    pipeline_erro_target string
)
USING DELTA
LOCATION '/mnt/log/pipeline/pipeline_execucao'
