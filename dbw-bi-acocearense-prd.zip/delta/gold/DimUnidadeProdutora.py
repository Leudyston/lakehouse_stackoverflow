# Databricks notebook source
# MAGIC %md # Projeto Aço Cearense
# MAGIC 
# MAGIC ### Tabela: DimUnidadeProdutora

# COMMAND ----------

import pyspark.sql.functions as F
import pandas as pd
from pyspark.sql.window import Window
from delta.tables import *
from pyspark.sql.utils import AnalysisException
from pyspark.sql.window import Window

# COMMAND ----------

param = {
    "tabela_gold": "DimUnidadeProdutora",
    "esquema_gold": "gold",
    "coluna_chave": "IdUnidadeProdutora",
    "local_tabela_gold": "/mnt/gold/producao/DimUnidadeProdutora"
}

# COMMAND ----------

dim_unidade_produtora = spark.read.table('silver.unidadeprodutora')

# COMMAND ----------

dim_unidade_produtora = dim_unidade_produtora.selectExpr('IdUnidadeProdutora',
                                                         'Codigo',            
                                                         'Descricao').distinct().orderBy('IdUnidadeProdutora')

# COMMAND ----------

dim_unidade_produtora = dim_unidade_produtora.withColumn('SkDimUnidadeProdutora', (F.row_number().over(Window.partitionBy().orderBy(param["coluna_chave"]))))

# COMMAND ----------

dim_unidade_produtora = dim_unidade_produtora.selectExpr('SkDimUnidadeProdutora',
                                                         'IdUnidadeProdutora',
                                                         'Codigo',
                                                         'Descricao')

# COMMAND ----------

dim_unidade_produtora.createOrReplaceTempView('dim_unidade_produtora')

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC SELECT 
# MAGIC           count(IdUnidadeProdutora), 
# MAGIC           IdUnidadeProdutora 
# MAGIC FROM 
# MAGIC           dim_unidade_produtora 
# MAGIC GROUP BY 
# MAGIC           IdUnidadeProdutora 
# MAGIC HAVING 
# MAGIC           COUNT(IdUnidadeProdutora) > 1

# COMMAND ----------

dim_unidade_produtora.write.format("delta").mode("overwrite").save(param["local_tabela_gold"])

# COMMAND ----------

spark.sql("DROP TABLE IF EXISTS {esquema_gold}.{tabela_gold}".format(**param))
spark.sql("CREATE TABLE {esquema_gold}.{tabela_gold} USING DELTA LOCATION '{local_tabela_gold}'".format(**param))
