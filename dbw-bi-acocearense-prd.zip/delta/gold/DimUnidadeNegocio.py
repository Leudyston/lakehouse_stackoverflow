# Databricks notebook source
# MAGIC %md # Projeto Aço Cearense
# MAGIC 
# MAGIC ### Tabela: DimUnidadeNegocio

# COMMAND ----------

import pyspark.sql.functions as F
import pandas as pd
from pyspark.sql.window import Window
from delta.tables import *
from pyspark.sql.utils import AnalysisException
from pyspark.sql.window import Window

# COMMAND ----------

param = {
    "tabela_gold": "DimUnidadeNegocio",
    "esquema_gold": "gold",
    "coluna_chave": "IdUnidadeNegocio",
    "local_tabela_gold": "/mnt/gold/producao/DimUnidadeNegocio"
}

# COMMAND ----------

dim_unidade_negocio = spark.read.table('silver.unidadenegocio')

# COMMAND ----------

dim_unidade_negocio = dim_unidade_negocio.select('IdUnidadeNegocio',
                                                 'Codigo',
                                                 'Nome').distinct().orderBy('IdUnidadeNegocio')

# COMMAND ----------

dim_unidade_negocio = dim_unidade_negocio.withColumn('SkDimUnidadeNegocio', (F.row_number().over(Window.partitionBy().orderBy(param["coluna_chave"]))))

# COMMAND ----------

dim_unidade_negocio = dim_unidade_negocio.select('SkDimUnidadeNegocio',
                                                 'IdUnidadeNegocio',
                                                 'Codigo',
                                                 'Nome')

# COMMAND ----------

dim_unidade_negocio.createOrReplaceTempView('dim_unidade_negocio')

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC SELECT 
# MAGIC           count(IdUnidadeNegocio), 
# MAGIC           IdUnidadeNegocio 
# MAGIC FROM 
# MAGIC           dim_unidade_negocio 
# MAGIC GROUP BY 
# MAGIC           IdUnidadeNegocio 
# MAGIC HAVING 
# MAGIC           COUNT(IdUnidadeNegocio) > 1

# COMMAND ----------

dim_unidade_negocio.write.format("delta").mode("overwrite").save(param["local_tabela_gold"])

# COMMAND ----------

spark.sql("DROP TABLE IF EXISTS {esquema_gold}.{tabela_gold}".format(**param))
spark.sql("CREATE TABLE {esquema_gold}.{tabela_gold} USING DELTA LOCATION '{local_tabela_gold}'".format(**param))
