# Databricks notebook source
# MAGIC %md # Projeto Aço Cearense
# MAGIC 
# MAGIC ### Tabela: DimTempo

# COMMAND ----------

dbutils.widgets.text('input_file','')

# COMMAND ----------

input_file = dbutils.widgets.get('input_file')

# COMMAND ----------

import os
import pyspark.sql.functions as F
import pandas as pd
from pyspark.sql.window import Window
from delta.tables import *
from pyspark.sql.utils import AnalysisException
from pyspark.sql.window import Window

# COMMAND ----------

os.system("pip install openpyxl")
os.system("pip install xlrd")
import xlrd
import openpyxl

# COMMAND ----------

param = {
    "tabela_gold": "DimTempo",
    "esquema_gold": "gold",
    "coluna_chave": "DtData",
    "local_tabela_gold": "/mnt/gold/producao/DimTempo"
}

# COMMAND ----------

dim_tempo = pd.read_excel(os.path.join('/dbfs/mnt/raw/file/',input_file), sheet_name='Plan1')

# COMMAND ----------

dim_tempo_df = spark.createDataFrame(dim_tempo).withColumn('dt_data', F.date_format(F.col('dt_data'), 'yyyy-MM-dd'))

# COMMAND ----------

dim_tempo = dim_tempo_df.selectExpr('dt_data         as DtData',
                                    'nu_dia_mes      as NuDiaMes',
                                    'nu_mes          as NuMes',
                                    'no_mes          as NoMes',
                                    'nu_ano          as NuAno',
                                    'nu_dia_semana   as NuDiaSemana',
                                    'no_dia_semana   as NoDiaSemana',
                                    'in_dia_util     as InDiaUtil',
                                    'nu_bimestre     as NuBimestre',
                                    'no_bimestre     as NoBimestre',
                                    'nu_trimestre    as NuTrimestre',
                                    'no_trimestre    as NoTrimestre',
                                    'nu_semestre     as NuSemestre',
                                    'no_semestre     as NoSemestre').distinct().orderBy('DtData')

# COMMAND ----------

dim_tempo = dim_tempo.withColumn('SkDimTempo', (F.row_number().over(Window.partitionBy().orderBy(param["coluna_chave"]))))

# COMMAND ----------

dim_tempo = dim_tempo.selectExpr('SkDimTempo',
                                    'DtData',
                                    'NuDiaMes',
                                    'NuMes',
                                    'NoMes',
                                    'NuAno',
                                    'NuDiaSemana',
                                    'NoDiaSemana',
                                    'InDiaUtil',
                                    'NuBimestre',
                                    'NoBimestre',
                                    'NuTrimestre',
                                    'NoTrimestre',
                                    'NuSemestre',
                                    'NoSemestre')

# COMMAND ----------

dim_tempo.write.format("delta").mode("overwrite").save(param["local_tabela_gold"])

# COMMAND ----------

spark.sql("DROP TABLE IF EXISTS {esquema_gold}.{tabela_gold}".format(**param))
spark.sql("CREATE TABLE {esquema_gold}.{tabela_gold} USING DELTA LOCATION '{local_tabela_gold}'".format(**param))
