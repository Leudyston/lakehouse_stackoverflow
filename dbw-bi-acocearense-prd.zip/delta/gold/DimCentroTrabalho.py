# Databricks notebook source
# MAGIC %md # Projeto Aço Cearense
# MAGIC 
# MAGIC ### Tabela: DimCentroTrabalho

# COMMAND ----------

import pyspark.sql.functions as F
import pandas as pd
from pyspark.sql.window import Window
from delta.tables import *
from pyspark.sql.utils import AnalysisException
from pyspark.sql.window import Window

# COMMAND ----------

param = {
    "tabela_gold": "DimCentroTrabalho",
    "esquema_gold": "gold",
    "coluna_chave": "IdCentroTrabalho",
    "local_tabela_gold": "/mnt/gold/producao/DimCentroTrabalho"
}

# COMMAND ----------

DimCentroTrabalho = spark.read.table('silver.centrotrabalho')

# COMMAND ----------

DimCentroTrabalho = DimCentroTrabalho.selectExpr('IdCentroTrabalho',
                                                 'Nome',            
                                                 'CodigoERP').distinct().orderBy('IdCentroTrabalho')

# COMMAND ----------

DimCentroTrabalho = DimCentroTrabalho.withColumn('SkDimCentroTrabalho', (F.row_number().over(Window.partitionBy().orderBy(param["coluna_chave"]))))

# COMMAND ----------

DimCentroTrabalho = DimCentroTrabalho.selectExpr('SkDimCentroTrabalho',
                                                 'IdCentroTrabalho',
                                                 'Nome',            
                                                 'CodigoERP')

# COMMAND ----------

DimCentroTrabalho.createOrReplaceTempView('DimCentroTrabalho')

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC SELECT 
# MAGIC           count(IdCentroTrabalho), 
# MAGIC           IdCentroTrabalho 
# MAGIC FROM 
# MAGIC           DimCentroTrabalho 
# MAGIC GROUP BY 
# MAGIC           IdCentroTrabalho 
# MAGIC HAVING 
# MAGIC           COUNT(IdCentroTrabalho) > 1

# COMMAND ----------

DimCentroTrabalho.write.format("delta").mode("overwrite").save(param["local_tabela_gold"])

# COMMAND ----------

spark.sql("DROP TABLE IF EXISTS {esquema_gold}.{tabela_gold}".format(**param))
spark.sql("CREATE TABLE {esquema_gold}.{tabela_gold} USING DELTA LOCATION '{local_tabela_gold}'".format(**param))
