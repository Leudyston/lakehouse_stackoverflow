# Databricks notebook source
# MAGIC %md # Projeto Aço Cearense
# MAGIC 
# MAGIC ### Tabela: DimTurnoTurmaCalendario

# COMMAND ----------

import pyspark.sql.functions as F
import pandas as pd
from pyspark.sql.window import Window
from delta.tables import *
from pyspark.sql.utils import AnalysisException
from pyspark.sql.window import Window

# COMMAND ----------

param = {
    "tabela_gold": "DimTurnoTurmaCalendario",
    "esquema_gold": "gold",
    "coluna_chave": "Id",
    "local_tabela_gold": "/mnt/gold/producao/DimTurnoTurmaCalendario"
}

# COMMAND ----------

DimTurnoTurmaCalendario = spark.read.table('silver.turnoturmacalendario')

# COMMAND ----------

DimTurnoTurmaCalendario = DimTurnoTurmaCalendario.selectExpr('Id',
                                                             'Referencia',  
                                                             'Inicio',
                                                             'Fim',
                                                             'Descricao').distinct().orderBy('Id')

# COMMAND ----------

DimTurnoTurmaCalendario = DimTurnoTurmaCalendario.withColumn('SkDimTurnoTurmaCalendario', (F.row_number().over(Window.partitionBy().orderBy(param["coluna_chave"]))))

# COMMAND ----------

DimTurnoTurmaCalendario = DimTurnoTurmaCalendario.selectExpr('SkDimTurnoTurmaCalendario',
                                                             'Id',
                                                             'Referencia',
                                                             'Inicio',
                                                             'Fim',
                                                             'Descricao')

# COMMAND ----------

DimTurnoTurmaCalendario.createOrReplaceTempView('DimTurnoTurmaCalendario')

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC SELECT 
# MAGIC           count(Id), 
# MAGIC           Id 
# MAGIC FROM 
# MAGIC           DimTurnoTurmaCalendario 
# MAGIC GROUP BY 
# MAGIC           Id 
# MAGIC HAVING 
# MAGIC           COUNT(Id) > 1

# COMMAND ----------

DimTurnoTurmaCalendario.write.format("delta").mode("overwrite").save(param["local_tabela_gold"])

# COMMAND ----------

spark.sql("DROP TABLE IF EXISTS {esquema_gold}.{tabela_gold}".format(**param))
spark.sql("CREATE TABLE {esquema_gold}.{tabela_gold} USING DELTA LOCATION '{local_tabela_gold}'".format(**param))
