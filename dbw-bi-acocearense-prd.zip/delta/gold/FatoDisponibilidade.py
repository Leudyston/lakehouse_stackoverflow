# Databricks notebook source
# MAGIC %md # Projeto Aço Cearense
# MAGIC 
# MAGIC ### Tabela: FatoDisponibilidade

# COMMAND ----------

import pyspark.sql.functions as F
import pandas as pd
from pyspark.sql.window import Window
from delta.tables import *
from pyspark.sql.utils import AnalysisException
from pyspark.sql.window import Window

# COMMAND ----------

param = {
    "tabela_gold": "FatoDisponibilidade",
    "esquema_gold": "gold",
    "local_tabela_gold": "/mnt/gold/producao/FatoDisponibilidade"
}

# COMMAND ----------

arvorecentro = spark.read.table('bronze.arvorecentro__gpp__gpp_hom__sinobras__sql_server')

arvoreparada = spark.read.table('bronze.arvoreparada__gpp__gpp_hom__sinobras__sql_server')

centrotrabalho = spark.read.table('bronze.centrotrabalho__gpp__gpp_hom__sinobras__sql_server')#.withColumnRenamed('IdCentroTrabalho', 'IdCentroTrabalhoCT')

parada = spark.read.table('bronze.parada__gpp__gpp_hom__sinobras__sql_server').withColumnRenamed('IdParada', 'IdParadaP')

programacaocentrotrabalho = spark.read.table('bronze.programacaocentrotrabalho__pcp__gpp_hom__sinobras__sql_server')

programacaoparada = spark.read.table('bronze.programacaoparada__pcp__gpp_hom__sinobras__sql_server').withColumnRenamed('IdParada', 'IdParadaPP')

turnogrupo = spark.read.table('bronze.turnogrupo__pcp__gpp_hom__sinobras__sql_server')

turnoturmacalendario = spark.read.table('bronze.turnoturmacalendario__pcp__gpp_hom__sinobras__sql_server').withColumnRenamed('Id','IdTTC')\
                                                                                                          .withColumnRenamed('Inicio','InicioTTC')\
                                                                                                          .withColumnRenamed('Fim','FimTTC')

turnoturmacalendariocentrotrabalho = spark.read.table('bronze.turnoturmacalendariocentrotrabalho__pcp__gpp_hom__sinobras__sql_server').withColumnRenamed('IdCentroTrabalho','IdCentroTrabalhoTTCCT')\
                                                                                                 .withColumnRenamed('Id','IdTTCCT')
                                                                                              
                                                                                                 

unidadenegocio = spark.read.table('bronze.unidadenegocio__gpp__gpp_hom__sinobras__sql_server')

unidadeprodutora = spark.read.table('bronze.unidadeprodutora__gpp__gpp_hom__sinobras__sql_server')

turnocontrole = spark.read.table('bronze.turnocontrole__pcp__gpp_hom__sinobras__sql_server')

turnoturmaparada = spark.read.table('bronze.turnoturmaparada__pcp__gpp_hom__sinobras__sql_server').withColumnRenamed('IdParada', 'IdParadaTTP')

programacaocentrotrabalho = spark.read.table('silver.programacaocentrotrabalho')  


 
dimcentrotrabalho             = spark.read.table('gold.dimcentrotrabalho')
dimtempo                      = spark.read.table('gold.dimtempo')
dimturnoturmacalendario       = spark.read.table('gold.dimturnoturmacalendario')
dimunidadenegocio             = spark.read.table('gold.dimunidadenegocio')
dimunidadeprodutora           = spark.read.table('gold.dimunidadeprodutora')

# COMMAND ----------

arvorecentro.createOrReplaceTempView('arvorecentro')
arvoreparada.createOrReplaceTempView('arvoreparada')
centrotrabalho.createOrReplaceTempView('centrotrabalho')
parada.createOrReplaceTempView('parada')
programacaocentrotrabalho.createOrReplaceTempView('programacaocentrotrabalho')
programacaoparada.createOrReplaceTempView('programacaoparada')
turnogrupo.createOrReplaceTempView('turnogrupo')
turnoturmacalendario.createOrReplaceTempView('turnoturmacalendario')
turnoturmacalendariocentrotrabalho.createOrReplaceTempView('turnoturmacalendariocentrotrabalho')
unidadenegocio.createOrReplaceTempView('unidadenegocio')
unidadeprodutora.createOrReplaceTempView('unidadeprodutora')
turnocontrole.createOrReplaceTempView('turnocontrole')
turnoturmaparada.createOrReplaceTempView('turnocontrole')

dimcentrotrabalho.createOrReplaceTempView('dimcentrotrabalho')        
dimtempo.createOrReplaceTempView('dimtempo')                 
dimturnoturmacalendario.createOrReplaceTempView('dimturnoturmacalendario')  
dimunidadenegocio.createOrReplaceTempView('dimunidadenegocio')        
dimunidadeprodutora.createOrReplaceTempView('dimunidadeprodutora')               

# COMMAND ----------

# DBTITLE 1,Query Base
query_base = spark.sql('''

SELECT DISTINCT
          CT.IdUnidadeProdutora,
          CT.IdCentroTrabalho            AS IdCentroTrabalhoQB,
          TTC.IdTTC                      AS IdTTCQB, 
          DAY(PC.MesAno)                 AS Dia,
          MONTH(PC.MesAno)               AS Mes,
          YEAR(PC.MesAno)                AS Ano,
          PC.Id                          AS IdPC,
          PC.IdProgramacaoProducao,
          TTC.InicioTTC                  AS InicioTTCQB,
          TTC.FimTTC                     AS FimTTCQB
FROM 
          centrotrabalho CT 
INNER JOIN
          programacaocentrotrabalho PC             ON CT.IdCentroTrabalho = PC.IdCentroTrabalho
INNER JOIN
          turnoturmacalendariocentrotrabalho TTCCT ON PC.IdCentroTrabalho = TTCCT.IdcentroTrabalhoTTCCT
INNER JOIN
          turnoturmacalendario TTC                 ON TTCCT.IdTurnosTurmasCalendario = TTC.IdTTC
AND
          DAY(TTC.Referencia) = DAY(PC.MesAno) 
AND
          MONTH(TTC.Referencia) = MONTH(PC.MesAno)
AND
          YEAR(TTC.Referencia) = YEAR(PC.MesAno)
GROUP BY 
			CT.IdUnidadeProdutora, 
	     	CT.IdCentroTrabalho, 
		 	PC.Id, 
		 	PC.IdProgramacaoProducao, 
		 	TTC.IdTTC,
		 	DAY(PC.MesAno), 
		 	MONTH(PC.MesAno), 
		 	YEAR(PC.MesAno), 
		 	TTC.InicioTTC,
		 	TTC.FimTTC
HAVING 
            CT.IdCentroTrabalho = 4
          
''')

query_base.createOrReplaceTempView('query_base')

# COMMAND ----------

#TempoParadaProgramada
DFTempoParadaProgramada = programacaoparada.join(parada, programacaoparada.IdParadaPP == parada.IdParadaP, 'left')\
                                           .join(turnoturmaparada, parada.IdParadaP == turnoturmaparada.IdParadaTTP, 'left')\
                                           .join(turnocontrole, turnoturmaparada.IdTurnoControle == turnocontrole.Id, 'left')\
                                           .join(turnoturmacalendariocentrotrabalho, turnocontrole.IdCalendarioCentroTrabalho == turnoturmacalendariocentrotrabalho.IdTTCCT, 'left')\
                                           .join(query_base, [query_base.IdPC == programacaoparada.IdProgramacaoCentroTrabalho,
                                                              turnoturmacalendariocentrotrabalho.IdTurnosTurmasCalendario == query_base.IdTTCQB], 'right')\
               .groupBy('IdUnidadeProdutora', query_base['IdCentroTrabalhoQB'], 'Mes', 'Dia', 'Ano', 'IdProgramacaoProducao', 'IdTTCQB', 'IdPC', query_base['InicioTTCQB'], query_base['FimTTCQB'])\
               .agg(F.sum((F.unix_timestamp(programacaoparada['DataFim'])-F.unix_timestamp(programacaoparada['DataInicio']))/60).alias('TempoParadaProgramada'))\
               .select('IdUnidadeProdutora', query_base['IdCentroTrabalhoQB'], 'Mes', 'Dia', 'Ano', 'IdProgramacaoProducao', 'IdTTCQB', 'IdPC', 'InicioTTCQB', 'FimTTCQB', 'TempoParadaProgramada')

# COMMAND ----------

DFTempoProgramado = turnoturmacalendariocentrotrabalho.join(turnoturmacalendario, turnoturmacalendariocentrotrabalho.IdTurnosTurmasCalendario == turnoturmacalendario.IdTTC)\
                                                      .join(query_base, [turnoturmacalendariocentrotrabalho.IdCentroTrabalhoTTCCT == query_base.IdCentroTrabalhoQB,
                                                                         turnoturmacalendario.IdTTC == query_base.IdTTCQB], 'right')\
               .groupBy('IdUnidadeProdutora', query_base['IdCentroTrabalhoQB'], 'Mes', 'Dia', 'Ano', 'IdProgramacaoProducao', 'IdTTCQB', 'IdPC', query_base['InicioTTCQB'], query_base['FimTTCQB'])\
               .agg(F.sum((F.unix_timestamp(turnoturmacalendario['FimTTC'])-F.unix_timestamp(turnoturmacalendario['InicioTTC']))/60).alias('TempoProgramado'))\
               .select('IdUnidadeProdutora', query_base['IdCentroTrabalhoQB'], 'Mes', 'Dia', 'Ano', 'IdProgramacaoProducao', 'IdTTCQB', 'IdPC', query_base['InicioTTCQB'], query_base['FimTTCQB'], 'TempoProgramado')

# COMMAND ----------

SubSelectTempoParado = query_base.join(turnoturmacalendariocentrotrabalho, query_base.IdTTCQB == turnoturmacalendariocentrotrabalho.IdTurnosTurmasCalendario)\
                                 .join(arvorecentro, query_base.IdCentroTrabalhoQB == arvorecentro.IdCentro)\
                                 .join(arvoreparada, arvorecentro.IdArvore == arvoreparada.Id)\
                                 .select('Raiz', 'IdCentroTrabalhoQB')\
                                 .withColumn("row",F.row_number().over(Window.partitionBy("IdCentroTrabalhoQB").orderBy(F.col('Raiz').desc())))\
                                 .filter(F.col('row') == 1)\
                                 .select('Raiz', 'IdCentroTrabalhoQB')

# COMMAND ----------

JoinArvoreParada = parada.join(arvoreparada, parada.IdArvoreParada == arvoreparada.Id)\
                         .join(turnoturmaparada, parada.IdParadaP == turnoturmaparada.IdParadaTTP)\
                         .join(turnocontrole, turnoturmaparada.IdTurnoControle == turnocontrole.Id)\
                         .join(turnoturmacalendariocentrotrabalho, turnocontrole.IdCalendarioCentroTrabalho == turnoturmacalendariocentrotrabalho.IdTTCCT)\
                         .select('DataInicio', 'DataFim', 'Raiz', 'IdTurnosTurmasCalendario')\
                         .withColumnRenamed('Raiz', 'Raiz_')

# COMMAND ----------

DFTempoParado = query_base.join(SubSelectTempoParado, 'IdCentroTrabalhoQB', 'left')\
                          .join(JoinArvoreParada, [F.expr("Raiz_ LIKE CONCAT(Raiz, '%')"),\
                                                   JoinArvoreParada.IdTurnosTurmasCalendario == query_base.IdTTCQB], 'left')\
                          .groupBy('IdUnidadeProdutora', query_base['IdCentroTrabalhoQB'], 'Mes', 'Dia', 'Ano', 'IdProgramacaoProducao', 'IdTTCQB', 'IdPC', query_base['InicioTTCQB'], query_base['FimTTCQB'])\
                           .agg(F.sum((F.unix_timestamp(F.col('DataFim'))-F.unix_timestamp(F.col('DataInicio')))/60).alias('TempoParado'))\
                           .select('IdUnidadeProdutora', query_base['IdCentroTrabalhoQB'], 'Mes', 'Dia', 'Ano', 'IdProgramacaoProducao', 'IdTTCQB', 'IdPC', 'InicioTTCQB', 'FimTTCQB', 'TempoParado')

# COMMAND ----------

df_final_medidas = (DFTempoParadaProgramada.join(DFTempoProgramado, ['IdUnidadeProdutora', 'IdCentroTrabalhoQB','Mes', 'Dia', 'Ano', 'IdProgramacaoProducao', 'IdTTCQB', 'IdPC', 'InicioTTCQB', 'FimTTCQB'], 'left')
                                           .join(DFTempoParado,     ['IdUnidadeProdutora', 'IdCentroTrabalhoQB','Mes', 'Dia', 'Ano', 'IdProgramacaoProducao', 'IdTTCQB', 'IdPC', 'InicioTTCQB', 'FimTTCQB'], 'left')
                                           .withColumn('AnoMesDia', F.date_format(F.concat(F.col('Ano'),F.lit('-'),F.col('Mes'),F.lit('-'),F.col('Dia')), 'yyyy-MM-dd'))
                                           .select(DFTempoParadaProgramada['IdUnidadeProdutora'], 
                                                   DFTempoParadaProgramada['IdCentroTrabalhoQB'],
                                                   DFTempoParadaProgramada['IdTTCQB'],
                                                   'TempoParadaProgramada',
                                                   'TempoProgramado',
                                                   'TempoParado',
                                                   'AnoMesDia'))


# date_format(date '1970-01-01', "dd-MM-yyyyy");#

# COMMAND ----------

df_fato_disponibilidade = df_final_medidas.join(dimcentrotrabalho,       df_final_medidas.IdCentroTrabalhoQB      == dimcentrotrabalho.IdCentroTrabalho)\
                           .join(dimunidadeprodutora,     df_final_medidas.IdUnidadeProdutora      == dimunidadeprodutora.IdUnidadeProdutora)\
                           .join(unidadeprodutora,        dimunidadeprodutora.IdUnidadeProdutora   == unidadeprodutora.IdUnidadeProdutora)\
                           .join(dimunidadenegocio,       unidadeprodutora.IdUnidadeNegocio        == dimunidadenegocio.IdUnidadeNegocio)\
                           .join(dimturnoturmacalendario, df_final_medidas.IdTTCQB == dimturnoturmacalendario.Id)\
                           .join(dimtempo,                df_final_medidas.AnoMesDia == dimtempo.DtData)

# COMMAND ----------

fato_disponibilidade = df_fato_disponibilidade.select('SkDimTurnoTurmaCalendario', 
                                                      'SkDimCentroTrabalho', 
                                                      'SkDimUnidadeProdutora', 
                                                      'SkDimUnidadeNegocio', 
                                                      'SkDimTempo', 
                                                      'TempoParado', 
                                                      'TempoProgramado', 
                                                      'TempoParadaProgramada')

# COMMAND ----------

fato_disponibilidade.write.format("delta").mode("overwrite").option("overwriteSchema", "true").save(param["local_tabela_gold"])

spark.sql("DROP TABLE IF EXISTS {esquema_gold}.{tabela_gold}".format(**param))
spark.sql("CREATE TABLE {esquema_gold}.{tabela_gold} USING DELTA LOCATION '{local_tabela_gold}'".format(**param))   
