# Databricks notebook source
# MAGIC %md # Projeto Aço Cearense
# MAGIC 
# MAGIC ### Tabela: UnidadeProdutora

# COMMAND ----------

import pyspark.sql.functions as F

# COMMAND ----------

param = {
    "tabela_silver": "UnidadeProdutora",
    "esquema_silver": "silver",
    "local_tabela_silver": "/mnt/silver/producao/UnidadeProdutora"
}

# COMMAND ----------

unidade_produtora = spark.read.table('bronze.unidadeprodutora__gpp__gpp_prd__sinobras__sql_server')

# COMMAND ----------

unidade_produtora.write.format("delta").mode("overwrite").option("overwriteSchema", "true").save(param["local_tabela_silver"])

# COMMAND ----------

spark.sql("DROP TABLE IF EXISTS {esquema_silver}.{tabela_silver}".format(**param))
spark.sql("CREATE TABLE {esquema_silver}.{tabela_silver} USING DELTA LOCATION '{local_tabela_silver}'".format(**param))
