# Databricks notebook source
# MAGIC %md # Projeto Aço Cearense
# MAGIC 
# MAGIC ### Tabela: Parada

# COMMAND ----------

import pyspark.sql.functions as F

# COMMAND ----------

param = {
    "tabela_silver": "Parada",
    "esquema_silver": "silver",
    "local_tabela_silver": "/mnt/silver/producao/Parada"
}

# COMMAND ----------

parada = spark.read.table('bronze.parada__gpp__gpp_prd__sinobras__sql_server')

# COMMAND ----------

parada = parada.withColumn('DataInicio', F.date_format(F.col('DataInicio'), 'yyyy-MM-dd HH:MM:SS'))\
               .withColumn('DataFim', F.date_format(F.col('DataFim'), 'yyyy-MM-dd HH:MM:SS'))\
               .withColumn('DataTpManager', F.date_format(F.col('DataTpManager'), 'yyyy-MM-dd HH:MM:SS'))

# COMMAND ----------

parada.write.format("delta").mode("overwrite").option("overwriteSchema", "true").save(param["local_tabela_silver"])

# COMMAND ----------

spark.sql("DROP TABLE IF EXISTS {esquema_silver}.{tabela_silver}".format(**param))
spark.sql("CREATE TABLE {esquema_silver}.{tabela_silver} USING DELTA LOCATION '{local_tabela_silver}'".format(**param))
