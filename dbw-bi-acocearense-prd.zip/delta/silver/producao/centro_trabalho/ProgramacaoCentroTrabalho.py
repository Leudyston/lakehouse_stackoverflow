# Databricks notebook source
# MAGIC %md # Projeto Aço Cearense
# MAGIC 
# MAGIC ### Tabela: ProgramacaoCentroTrabalho

# COMMAND ----------

import pyspark.sql.functions as F

# COMMAND ----------

param = {
    "tabela_silver": "ProgramacaoCentroTrabalho",
    "esquema_silver": "silver",
    "local_tabela_silver": "/mnt/silver/producao/ProgramacaoCentroTrabalho"
}

# COMMAND ----------

ProgramacaoCentroTrabalho = spark.read.table('bronze.programacaocentrotrabalho__pcp__gpp_prd__sinobras__sql_server')

# COMMAND ----------

ProgramacaoCentroTrabalho = ProgramacaoCentroTrabalho.withColumn('MesAno', F.date_format(F.col('MesAno'), 'yyyy-MM-dd HH:MM:SS'))\
                                                     .withColumn('DataRegistro', F.date_format(F.col('DataRegistro'), 'yyyy-MM-dd HH:MM:SS'))       

# COMMAND ----------

ProgramacaoCentroTrabalho.write.format("delta").mode("overwrite").option("overwriteSchema", "true").save(param["local_tabela_silver"])

# COMMAND ----------

spark.sql("DROP TABLE IF EXISTS {esquema_silver}.{tabela_silver}".format(**param))
spark.sql("CREATE TABLE {esquema_silver}.{tabela_silver} USING DELTA LOCATION '{local_tabela_silver}'".format(**param))
