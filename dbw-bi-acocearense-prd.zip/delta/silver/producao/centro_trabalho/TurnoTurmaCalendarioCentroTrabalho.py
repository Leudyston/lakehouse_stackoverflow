# Databricks notebook source
# MAGIC %md # Projeto Aço Cearense
# MAGIC 
# MAGIC ### Tabela: TurnoTurmaCalendarioCentroTrabalho

# COMMAND ----------

param = {
    "tabela_silver": "TurnoTurmaCalendarioCentroTrabalho",
    "esquema_silver": "silver",
    "local_tabela_silver": "/mnt/silver/producao/TurnoTurmaCalendarioCentroTrabalho"
}

# COMMAND ----------

TurnoTurmaCalendarioCentroTrabalho = spark.read.table('bronze.turnoturmacalendariocentrotrabalho__pcp__gpp_prd__sinobras__sql_server')

# COMMAND ----------

TurnoTurmaCalendarioCentroTrabalho.write.format("delta").mode("overwrite").option("overwriteSchema", "true").save(param["local_tabela_silver"])

# COMMAND ----------

spark.sql("DROP TABLE IF EXISTS {esquema_silver}.{tabela_silver}".format(**param))
spark.sql("CREATE TABLE {esquema_silver}.{tabela_silver} USING DELTA LOCATION '{local_tabela_silver}'".format(**param))
